package com.auction.auctionapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuctionappApplication {

    public static void main(String[] args) {
        SpringApplication.run(AuctionappApplication.class, args);
    }

}
