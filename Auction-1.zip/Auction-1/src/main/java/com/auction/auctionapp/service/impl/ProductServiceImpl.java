package com.auction.auctionapp.service.impl;
/*
import com.auction.auctionapp.repository.ProductRepository;
import com.auction.auctionapp.service.ProductService;
import com.auction.auctionapp.domain.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Override
    public void createProduct(Product product) {

        System.out.println("주문 생성: 경매 ID = " + product.getProductId() + ", 구매자 ID = " + product.getName());

    }
}
*/