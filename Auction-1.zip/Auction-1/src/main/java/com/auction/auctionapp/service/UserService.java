package com.auction.auctionapp.service;

import com.auction.auctionapp.domain.User;

import java.util.List;

public interface UserService {

    boolean login(String userId, String password);

    void signup(String userId, String password, String email);

    void updateProfile(String userId, String newEmail, String newPassword);

    void register(User user);
    List<User> getAllMembers();
}
