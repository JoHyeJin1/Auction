package com.auction.auctionapp.controller;

import com.auction.auctionapp.domain.User;
import com.auction.auctionapp.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

//회원가입과 로그인
@Controller
@RequestMapping("api/member")
public class MemberController {

    @Autowired
    private UserRepository userRepository;

    // 회원가입 폼 페이지
    @GetMapping("/join")
    public String showJoin() {
        return "member/join";
    }

    // 로그인 폼 페이지
    @GetMapping("/login")
    public String showLogin() {
        return "member/login";
    }

    // 회원가입 처리 POST 요청
    @PostMapping("/join")
    public String registerCustomer(@ModelAttribute User user, Model model) {
        Optional<User> existingUser = userRepository.findByUserId(user.getUserId());
        if (existingUser.isPresent()) {
            return "member/join"; // 다시 회원가입 페이지로
        }
        userRepository.save(user);
        return "member/joinSuccess";
    }

    @GetMapping("/joinSuccess")
    public String showJoinSuccess() {
        return "joinSuccess";
    }

    @PostMapping("/login")
    public String doLogin(@RequestParam String id,
                          @RequestParam String password,
                          Model model,
                          HttpSession session) {

        Optional<User> user = userRepository.findByUserIdAndPassword(id, password);

        if (user.isPresent()) {
            session.setAttribute("loginUser", user.get());
            model.addAttribute("nickname", user.get().getNickname());
            return "member/loginSuccess";
        } else {
            model.addAttribute("loginError", "아이디 또는 비밀번호가 일치하지 않습니다.");
            return "member/login";
        }
    }
}