package com.auction.auctionapp.controller;

import com.auction.auctionapp.model.Customer;
import com.auction.auctionapp.repository.CustomerRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("member")
public class MemberController {

    @Autowired
    private CustomerRepository customerRepository;

    // 회원가입 폼 페이지
    @GetMapping("/join")
    public String showJoin() {
        return "member/join";
    }

    // 로그인 폼 페이지
    @GetMapping("/login")
    public String showLogin() {
        return "member/login";
    }

    // ✅ 회원가입 처리 POST 요청
    @PostMapping("/join")
    public String registerCustomer(@ModelAttribute Customer customer) {
        customerRepository.save(customer);
        return "member/joinSuccess";
    }

    @GetMapping("/joinSuccess")
    public String showJoinSuccess() {
        return "joinSuccess";
    }

    @PostMapping("/login")
    public String doLogin(@RequestParam String id,
                          @RequestParam String password,
                          Model model,
                          HttpSession session) {

        Optional<Customer> customer = customerRepository.findByIdAndPassword(id, password);

        if (customer.isPresent()) {
            session.setAttribute("loginUser", customer.get());
            model.addAttribute("nickname", customer.get().getNickname());
            return "member/loginSuccess";
        } else {
            model.addAttribute("loginError", "아이디 또는 비밀번호가 일치하지 않습니다.");
            return "member/login";
        }
    }

}
