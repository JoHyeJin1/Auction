package com.auction.auctionapp.service.impl;

import java.util.List;

import com.auction.auctionapp.domain.User;
import com.auction.auctionapp.repository.UserRepository;
import org.springframework.stereotype.Service;

import com.auction.auctionapp.service.UserService;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository){
        this.userRepository = userRepository;
    }

    @Override
    public void register(User user){
        userRepository.save(user);
    }

    @Override
    public List<User> getAllMembers(){
        return userRepository.findAll();
    }

    @Override
    public boolean login(String userId, String password) {
        // TODO: 로그인 로직 작성
        System.out.println("로그인 시도: " + userId);
        return true; // 지금은 더미(true) 반환
    }

    @Override
    public void signup(String userId, String password, String email) {
        // TODO: 회원가입 로직 작성
        System.out.println("회원가입 시도: " + userId + ", " + email);
    }

    @Override
    public void updateProfile(String userId, String newEmail, String newPassword) {
        // TODO: 프로필 수정 로직 작성
        System.out.println("프로필 수정 시도: " + userId);
    }
}