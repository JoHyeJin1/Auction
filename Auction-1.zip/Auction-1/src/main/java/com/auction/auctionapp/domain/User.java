package com.auction.auctionapp.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "`user`") // user는 MySQL 예약어이므로 백틱으로 감쌈
public class User {

    @Id
    @Column(name = "user_id")
    private String userId;

    private String password;
    private String nickname;
    private String email;

    @Column(name = "phone_number")
    private String phoneNumber;

    private String address;

    private String category;

    // 연관 관계 (Optional - JPA용)
    @OneToMany(mappedBy = "seller")
    private List<Product> products;

    @OneToMany(mappedBy = "user")
    private List<Bid> bids;

    @OneToMany(mappedBy = "user")
    private List<Interest> interests;

    @OneToMany(mappedBy = "buyer")
    private List<Order> orders;

    @OneToMany(mappedBy = "user")
    private List<Seller_Inquiry> sellerInquiries;
}
