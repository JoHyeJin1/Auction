package com.auction.auctionapp.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "`user`") // user는 MySQL 예약어이므로 백틱으로 감쌈
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_no")
    private Long userNo;

    private String nickname;

    @Column(name = "user_id", nullable = false, unique = true)
    private String userId;

    @Column(nullable = false)
    private String password;

    private String address;
    private String category;
    private String email;
    private String phoneNumber;
    private String bank;
    private String accountNo;

    // 연관 관계 (양방향 JPA 매핑)
    @OneToMany(mappedBy = "seller")
    private List<Product> products;

    @OneToMany(mappedBy = "user")
    private List<Bid> bids;

    @OneToMany(mappedBy = "user")
    private List<Interest> interests;

    @OneToMany(mappedBy = "buyer")
    private List<Order> orders;

    @OneToMany(mappedBy = "user")
    private List<Seller_Inquiry> sellerInquiries;
}