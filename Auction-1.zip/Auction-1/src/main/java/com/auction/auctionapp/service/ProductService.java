package com.auction.auctionapp.service;

import com.auction.auctionapp.domain.Product;

public interface ProductService {
    void createProduct(Product product);
}
