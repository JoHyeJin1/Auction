package dao;

import com.auction.auctionapp.domain.User;

public interface UserDao {
        User findById(String userId);
        void updateUser(User user);
        void deleteUser(String userId);
        void insertUser(User user); // ✔️ 인터페이스에는 선언만
}