package com.auction.auctionapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuctionappApplicationTests {

    @Test
    void contextLoads() {
    }

}